--
-- PostgreSQL database dump
--

\restrict GNhqBaJGqlTpPpPo7huQugEsFZzEnHXXz6TQidenlBO3Q1rMBctwHjjPitiIC6o

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attendance_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance_devices (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    "ipAddress" character varying(64) NOT NULL,
    port integer DEFAULT 4370 NOT NULL,
    "commKey" integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "syncIntervalSeconds" integer DEFAULT 30 NOT NULL,
    "deviceUid" character varying(100),
    "deviceName" character varying(100),
    firmware character varying(100),
    platform character varying(100),
    status character varying(20) DEFAULT 'unknown'::character varying NOT NULL,
    "lastSyncAt" timestamp with time zone,
    "lastError" text,
    "lastErrorAt" timestamp with time zone,
    "totalSynced" bigint DEFAULT 0 NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_attendance_devices_commkey CHECK ((("commKey" >= 0) AND ("commKey" <= 65535))),
    CONSTRAINT ck_attendance_devices_interval CHECK ((("syncIntervalSeconds" >= 5) AND ("syncIntervalSeconds" <= 86400))),
    CONSTRAINT ck_attendance_devices_port CHECK (((port >= 1) AND (port <= 65535))),
    CONSTRAINT ck_attendance_devices_status CHECK (((status)::text = ANY ((ARRAY['unknown'::character varying, 'online'::character varying, 'offline'::character varying, 'disabled'::character varying, 'syncing'::character varying])::text[])))
);


ALTER TABLE public.attendance_devices OWNER TO postgres;

--
-- Name: attendance_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendance_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_devices_id_seq OWNER TO postgres;

--
-- Name: attendance_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendance_devices_id_seq OWNED BY public.attendance_devices.id;


--
-- Name: device_sync_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_sync_state (
    "deviceId" bigint NOT NULL,
    "lastRecordTime" timestamp with time zone,
    "totalRead" bigint DEFAULT 0 NOT NULL,
    "totalNew" bigint DEFAULT 0 NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.device_sync_state OWNER TO postgres;

--
-- Name: wa_chat_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_chat_settings (
    remote_jid character varying(100) NOT NULL,
    auto_reply boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wa_chat_settings OWNER TO postgres;

--
-- Name: wa_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_rules (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    match_type character varying(16) DEFAULT 'exact'::character varying NOT NULL,
    pattern text NOT NULL,
    response text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT wa_rules_match CHECK (((match_type)::text = ANY ((ARRAY['exact'::character varying, 'contains'::character varying, 'command'::character varying])::text[])))
);


ALTER TABLE public.wa_rules OWNER TO postgres;

--
-- Name: wa_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wa_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wa_rules_id_seq OWNER TO postgres;

--
-- Name: wa_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wa_rules_id_seq OWNED BY public.wa_rules.id;


--
-- Name: wa_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_settings (
    key character varying(80) NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wa_settings OWNER TO postgres;

--
-- Name: wa_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(20) NOT NULL,
    ar text NOT NULL,
    en text NOT NULL,
    variables integer DEFAULT 0 NOT NULL,
    is_builtin boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT wa_templates_category_check CHECK (((category)::text = ANY ((ARRAY['UTILITY'::character varying, 'AUTHENTICATION'::character varying, 'MARKETING'::character varying, 'SERVICE'::character varying])::text[])))
);


ALTER TABLE public.wa_templates OWNER TO postgres;

--
-- Name: wa_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wa_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wa_templates_id_seq OWNER TO postgres;

--
-- Name: wa_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wa_templates_id_seq OWNED BY public.wa_templates.id;


--
-- Name: wa_webhooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_webhooks (
    id integer NOT NULL,
    event character varying(50) NOT NULL,
    url text NOT NULL,
    secret text NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wa_webhooks OWNER TO postgres;

--
-- Name: wa_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wa_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wa_webhooks_id_seq OWNER TO postgres;

--
-- Name: wa_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wa_webhooks_id_seq OWNED BY public.wa_webhooks.id;


--
-- Name: wa_workflows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wa_workflows (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    flow_key character varying(100) NOT NULL,
    definition jsonb NOT NULL,
    is_active boolean DEFAULT false,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.wa_workflows OWNER TO postgres;

--
-- Name: wa_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wa_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wa_workflows_id_seq OWNER TO postgres;

--
-- Name: wa_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wa_workflows_id_seq OWNED BY public.wa_workflows.id;


--
-- Name: attendance_devices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_devices ALTER COLUMN id SET DEFAULT nextval('public.attendance_devices_id_seq'::regclass);


--
-- Name: wa_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_rules ALTER COLUMN id SET DEFAULT nextval('public.wa_rules_id_seq'::regclass);


--
-- Name: wa_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_templates ALTER COLUMN id SET DEFAULT nextval('public.wa_templates_id_seq'::regclass);


--
-- Name: wa_webhooks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_webhooks ALTER COLUMN id SET DEFAULT nextval('public.wa_webhooks_id_seq'::regclass);


--
-- Name: wa_workflows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_workflows ALTER COLUMN id SET DEFAULT nextval('public.wa_workflows_id_seq'::regclass);


--
-- Name: attendance_devices attendance_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_devices
    ADD CONSTRAINT attendance_devices_pkey PRIMARY KEY (id);


--
-- Name: device_sync_state device_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_sync_state
    ADD CONSTRAINT device_sync_state_pkey PRIMARY KEY ("deviceId");


--
-- Name: attendance_devices uq_attendance_devices_endpoint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_devices
    ADD CONSTRAINT uq_attendance_devices_endpoint UNIQUE ("ipAddress", port);


--
-- Name: wa_chat_settings wa_chat_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_chat_settings
    ADD CONSTRAINT wa_chat_settings_pkey PRIMARY KEY (remote_jid);


--
-- Name: wa_rules wa_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_rules
    ADD CONSTRAINT wa_rules_pkey PRIMARY KEY (id);


--
-- Name: wa_settings wa_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_settings
    ADD CONSTRAINT wa_settings_pkey PRIMARY KEY (key);


--
-- Name: wa_templates wa_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_templates
    ADD CONSTRAINT wa_templates_name_key UNIQUE (name);


--
-- Name: wa_templates wa_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_templates
    ADD CONSTRAINT wa_templates_pkey PRIMARY KEY (id);


--
-- Name: wa_webhooks wa_webhooks_event_url_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_webhooks
    ADD CONSTRAINT wa_webhooks_event_url_key UNIQUE (event, url);


--
-- Name: wa_webhooks wa_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_webhooks
    ADD CONSTRAINT wa_webhooks_pkey PRIMARY KEY (id);


--
-- Name: wa_workflows wa_workflows_flow_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_workflows
    ADD CONSTRAINT wa_workflows_flow_key_key UNIQUE (flow_key);


--
-- Name: wa_workflows wa_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wa_workflows
    ADD CONSTRAINT wa_workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_attendance_devices_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_devices_uid ON public.attendance_devices USING btree ("deviceUid");


--
-- Name: idx_wa_templates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wa_templates_name ON public.wa_templates USING btree (name);


--
-- Name: idx_wa_webhooks_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wa_webhooks_event ON public.wa_webhooks USING btree (event);


--
-- Name: idx_wa_workflows_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wa_workflows_active ON public.wa_workflows USING btree (is_active);


--
-- Name: idx_wa_workflows_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wa_workflows_key ON public.wa_workflows USING btree (flow_key);


--
-- Name: uq_wa_rules_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_wa_rules_name ON public.wa_rules USING btree (name, match_type, pattern);


--
-- Name: device_sync_state device_sync_state_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_sync_state
    ADD CONSTRAINT "device_sync_state_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public.attendance_devices(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GNhqBaJGqlTpPpPo7huQugEsFZzEnHXXz6TQidenlBO3Q1rMBctwHjjPitiIC6o

