--
-- PostgreSQL database dump
--

\restrict koKfPS50T80oEsnKt6dvITxiWIMJvJCk7oEgzZBJUxzQNbCmzARXMJMuZiSytmv

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: attendance_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: device_sync_state; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: wa_chat_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: wa_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (1, 'تحية', 'exact', 'السلام عليكم', 'وعليكم السلام ورحمة الله — مطاعم الشرفه العالمي ترحب بكم. أرسلوا «مساعدة» لعرض الأوامر.', true, 10, '2026-09-20 05:10:43.751536+03', '2026-09-20 05:10:43.751536+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (2, 'greeting', 'exact', 'hello', 'Hello — Al Shorfa Restaurants. Send "help" for commands.', true, 10, '2026-09-20 05:10:43.757755+03', '2026-09-20 05:10:43.757755+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (3, 'مساعدة', 'exact', 'مساعدة', 'الأوامر: مساعدة — تقرير — مخزن — مخزون <صنف> — حضور — حضور <اسم> [من] [إلى] — موظفين — رواتب — إجازات — وثائق — نواقص — حالة طلب <رقم> — ساعات العمل — إيراد اليوم — إيراد أمس — إيراد كاشير <رقم> — تقفيل اليوم.', true, 20, '2026-09-20 05:10:43.758596+03', '2026-09-20 05:10:43.758596+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (4, 'help', 'exact', 'help', 'Commands: help — order <number> — hours.', true, 20, '2026-09-20 05:10:43.759514+03', '2026-09-20 05:10:43.759514+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (5, 'ساعات العمل', 'exact', 'ساعات العمل', 'يوميًا من 9 صباحًا حتى 12 منتصف الليل.', true, 30, '2026-09-20 05:10:43.760201+03', '2026-09-20 05:10:43.760201+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (6, 'حالة طلب', 'command', 'حالة طلب', '', true, 40, '2026-09-20 05:10:43.760882+03', '2026-09-20 05:10:43.760882+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (7, 'order status', 'command', 'order', '', true, 40, '2026-09-20 05:10:43.76177+03', '2026-09-20 05:10:43.76177+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (8, 'تقرير المدير', 'command', 'تقرير', '', true, 50, '2026-09-20 05:10:43.76277+03', '2026-09-20 05:10:43.76277+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (9, 'مخزن', 'command', 'مخزن', '', true, 51, '2026-09-20 05:10:43.763563+03', '2026-09-20 05:10:43.763563+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (10, 'حضور', 'command', 'حضور', '', true, 52, '2026-09-20 05:10:43.764237+03', '2026-09-20 05:10:43.764237+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (11, 'موظفين', 'command', 'موظفين', '', true, 53, '2026-09-20 05:10:43.764879+03', '2026-09-20 05:10:43.764879+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (12, 'رواتب', 'command', 'رواتب', '', true, 54, '2026-09-20 05:10:43.765666+03', '2026-09-20 05:10:43.765666+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (13, 'إجازات', 'command', 'إجازات', '', true, 55, '2026-09-20 05:10:43.767083+03', '2026-09-20 05:10:43.767083+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (14, 'وثائق', 'command', 'وثائق', '', true, 56, '2026-09-20 05:10:43.769376+03', '2026-09-20 05:10:43.769376+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (15, 'نواقص', 'command', 'نواقص', '', true, 57, '2026-09-20 05:10:43.771251+03', '2026-09-20 05:10:43.771251+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (16, 'إيراد', 'command', 'إيراد', '', true, 58, '2026-09-20 05:10:43.772948+03', '2026-09-20 05:10:43.772948+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (17, 'ايراد', 'command', 'ايراد', '', true, 58, '2026-09-20 05:10:43.773969+03', '2026-09-20 05:10:43.773969+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (18, 'تقفيل', 'command', 'تقفيل', '', true, 59, '2026-09-20 05:10:43.774691+03', '2026-09-20 05:10:43.774691+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (19, 'مبيعات الكاشير', 'command', 'مبيعات', '', true, 60, '2026-09-20 05:10:43.775512+03', '2026-09-20 05:10:43.775512+03');
INSERT INTO public.wa_rules (id, name, match_type, pattern, response, enabled, priority, created_at, updated_at) VALUES (153, 'qa-probe', 'exact', 'qa-probe-xyz', '', false, 100, '2026-09-20 20:36:56.880776+03', '2026-09-20 20:36:56.965033+03');


--
-- Data for Name: wa_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.wa_settings (key, value, updated_at) VALUES ('wa_migration_055', '2026-09-19', '2026-09-20 05:10:28.524588+03');
INSERT INTO public.wa_settings (key, value, updated_at) VALUES ('manager_jids', '["966560229281"]', '2026-09-20 20:38:27.160931+03');
INSERT INTO public.wa_settings (key, value, updated_at) VALUES ('wa_session_first_seen', '2026-09-20T17:41:27.327Z', '2026-09-20 20:41:27.328595+03');
INSERT INTO public.wa_settings (key, value, updated_at) VALUES ('wa_migration_056', '2026-09-20', '2026-09-20 20:48:43.390801+03');


--
-- Data for Name: wa_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.wa_templates (id, name, category, ar, en, variables, is_builtin, created_at, updated_at) VALUES (1, 'order_confirm', 'UTILITY', '✅ تأكيد الطلب\nالطلب #{{1}}\nالمجموع: {{2}} ر.س\nالحالة: تم الاستلام', '✅ Order Confirmation\nOrder #{{1}}\nTotal: {{2}} SAR', 2, true, '2026-09-20 05:10:28.516909', '2026-09-20 05:10:28.516909');
INSERT INTO public.wa_templates (id, name, category, ar, en, variables, is_builtin, created_at, updated_at) VALUES (2, 'delivery_update', 'UTILITY', '🚚 تحديث التوصيل\nالطلب #{{1}}\nالحالة: {{2}}\nالموظف: {{3}}', '🚚 Delivery Update\nOrder #{{1}}\nStatus: {{2}}\nDriver: {{3}}', 3, true, '2026-09-20 05:10:28.516909', '2026-09-20 05:10:28.516909');
INSERT INTO public.wa_templates (id, name, category, ar, en, variables, is_builtin, created_at, updated_at) VALUES (3, 'payment_receipt', 'UTILITY', '🧾 إيصال الدفع\nالمبلغ: {{2}} ر.س\nرقم المعاملة: {{1}}', '🧾 Payment Receipt\nAmount: {{2}} SAR\nTransaction: {{1}}', 2, true, '2026-09-20 05:10:28.516909', '2026-09-20 05:10:28.516909');
INSERT INTO public.wa_templates (id, name, category, ar, en, variables, is_builtin, created_at, updated_at) VALUES (4, 'welcome', 'AUTHENTICATION', '🎉 أهلاً بكم في مطاعم الشرفة العالمي!\nاختر من القائمة:\n1. 📋 طلب جديد\n2. 📊 متابعة طلب\n3. 📞 خدمة العملاء', '🎉 Welcome to Al-Shorfa Restaurants!\nChoose from menu:\n1. 📋 New Order\n2. 📊 Track Order\n3. 💬 Support', 0, true, '2026-09-20 05:10:28.516909', '2026-09-20 05:10:28.516909');


--
-- Data for Name: wa_webhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: wa_workflows; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.wa_workflows (id, name, flow_key, definition, is_active, created_by, created_at, updated_at) VALUES (1, 'Welcome Flow', 'welcome_flow', '{"id": "welcome_flow", "name": "Welcome Flow", "nodes": {"end": {"type": "end"}, "confirm": {"next": "end", "text": "order_confirm", "type": "message"}, "welcome": {"next": "ask_type", "text": "welcome", "type": "message"}, "ask_type": {"text": "ماذا تريد؟", "type": "question", "options": [{"next": "collect_order", "text": "طلب جديد"}, {"next": "track_order", "text": "متابعة طلب"}, {"next": "agent_transfer", "text": "خدمة العملاء"}]}, "track_order": {"next": "lookup", "text": "أدخل رقم الطلب", "type": "question"}, "collect_order": {"next": "confirm", "type": "api_call", "endpoint": "/api/orders/new"}, "agent_transfer": {"type": "transfer", "agentId": "support"}}, "start": "welcome"}', true, 'system', '2026-09-20 05:10:28.52086', '2026-09-20 05:10:28.52086');


--
-- Name: attendance_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendance_devices_id_seq', 1, false);


--
-- Name: wa_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wa_rules_id_seq', 210, true);


--
-- Name: wa_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wa_templates_id_seq', 4, true);


--
-- Name: wa_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wa_webhooks_id_seq', 1, false);


--
-- Name: wa_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wa_workflows_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

\unrestrict koKfPS50T80oEsnKt6dvITxiWIMJvJCk7oEgzZBJUxzQNbCmzARXMJMuZiSytmv

